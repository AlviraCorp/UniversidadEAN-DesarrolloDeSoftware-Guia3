package com.mycompany.centraldepacientes;
import java.util.Scanner;
public class CentraldePacientes {

    // Clase interna Paciente
    static class Paciente {
        int id;
        String nombre;
        int edad;
        String clinica;
        Paciente siguiente;

        public Paciente(int id, String nombre, int edad, String clinica) {
            this.id = id;
            this.nombre = nombre;
            this.edad = edad;
            this.clinica = clinica;
            this.siguiente = null;
        }
    }

    // Clase interna ListaPacientes
    static class ListaPacientes {
        private Paciente cabeza;

        public ListaPacientes() {
            this.cabeza = null;
        }

        public boolean existeID(int id) {
            Paciente actual = cabeza;
            while (actual != null) {
                if (actual.id == id) {
                    return true;
                }
                actual = actual.siguiente;
            }
            return false;
        }

        public void agregarPaciente(int id, String nombre, int edad, String clinica) {
            if (existeID(id)) {
                System.out.println("Error: El ID " + id + " ya existe.");
                return;
            }

            Paciente nuevo = new Paciente(id, nombre, edad, clinica);
            if (cabeza == null) {
                cabeza = nuevo;
            } else {
                Paciente actual = cabeza;
                while (actual.siguiente != null) {
                    actual = actual.siguiente;
                }
                actual.siguiente = nuevo;
            }
            System.out.println("Paciente " + nombre + " agregado con ID " + id);
        }

        public String buscarPaciente(int id) {
            Paciente actual = cabeza;
            while (actual != null) {
                if (actual.id == id) {
                    return "ID: " + actual.id + ", Nombre: " + actual.nombre +
                           ", Edad: " + actual.edad + ", Clinica: " + actual.clinica;
                }
                actual = actual.siguiente;
            }
            return "Paciente no encontrado";
        }

        public void eliminarPaciente(int id) {
            Paciente actual = cabeza;
            Paciente anterior = null;
            while (actual != null) {
                if (actual.id == id) {
                    if (anterior != null) {
                        anterior.siguiente = actual.siguiente;
                    } else {
                        cabeza = actual.siguiente;
                    }
                    System.out.println("Paciente con ID " + id + " eliminado");
                    return;
                }
                anterior = actual;
                actual = actual.siguiente;
            }
            System.out.println("Paciente no encontrado");
        }

        public void modificarPaciente(int id, String nuevoNombre, int nuevaEdad, String nuevaClinica) {
            Paciente actual = cabeza;
            while (actual != null) {
                if (actual.id == id) {
                    actual.nombre = nuevoNombre;
                    actual.edad = nuevaEdad;
                    actual.clinica = nuevaClinica;
                    System.out.println("Paciente con ID " + id + " modificado correctamente.");
                    return;
                }
                actual = actual.siguiente;
            }
            System.out.println("Paciente no encontrado.");
        }

        public void mostrarPacientes() {
            Paciente actual = cabeza;
            if (actual == null) {
                System.out.println("No hay pacientes registrados");
                return;
            }
            while (actual != null) {
                System.out.println("ID: " + actual.id + ", Nombre: " + actual.nombre +
                                   ", Edad: " + actual.edad + ", Clínica: " + actual.clinica);
                actual = actual.siguiente;
            }
        }
    }

    // Método main con el menú
    public static void main(String[] args) {
        ListaPacientes lista = new ListaPacientes();
        Scanner sc = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\n--- Central de Pacientes ---");
            System.out.println("1. Agregar Paciente");
            System.out.println("2. Buscar Paciente");
            System.out.println("3. Eliminar Paciente");
            System.out.println("4. Mostrar Todos los Pacientes");
            System.out.println("5. Modificar Paciente");
            System.out.println("6. Salir");
            System.out.print("Elige una opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1:
                    System.out.print("ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nombre: ");
                    String nombre = sc.nextLine();
                    System.out.print("Edad: ");
                    int edad = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Clinica: ");
                    String clinica = sc.nextLine();
                    lista.agregarPaciente(id, nombre, edad, clinica);
                    break;

                case 2:
                    System.out.print("ID del paciente a buscar: ");
                    int idBuscar = sc.nextInt();
                    System.out.println(lista.buscarPaciente(idBuscar));
                    break;

                case 3:
                    System.out.print("ID del paciente a eliminar: ");
                    int idEliminar = sc.nextInt();
                    lista.eliminarPaciente(idEliminar);
                    break;

                case 4:
                    lista.mostrarPacientes();
                    break;

                case 5:
                    System.out.print("ID del paciente a modificar: ");
                    int idMod = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nuevo nombre: ");
                    String nuevoNombre = sc.nextLine();
                    System.out.print("Nueva edad: ");
                    int nuevaEdad = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nueva clinica: ");
                    String nuevaClinica = sc.nextLine();
                    lista.modificarPaciente(idMod, nuevoNombre, nuevaEdad, nuevaClinica);
                    break;

                case 6:
                    System.out.println("Saliendo del sistema...");
                    break;

                default:
                    System.out.println("Opcion no válida");
            }
        } while (opcion != 6);

        sc.close();
    }
}